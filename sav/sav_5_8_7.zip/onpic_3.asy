// 1. SCIENTIFIC COMPACT WRAPPER FOR PAPERS
size(14cm, 0, Aspect); 
import graph;

// --- GEOMETRIC CONFIGURATION (TRUE ARC 80 TO 90 DEGREES) ---
real r = 10;
real angle_start = 90; // Начинаем с 90 градусов (левый верхний угол)
real angle_end = 80;   // Двигаемся вправо до 80 градусов

real x_start_raw = r * cos(angle_start * pi / 180); 
real x_end_raw = r * cos(angle_end * pi / 180); 
real y_start_raw = r * sin(angle_start * pi / 180); 
real y_end_raw = r * sin(angle_end * pi / 180);

real xmin = 0;
real xmax = x_end_raw - x_start_raw; // Физическая ширина 10-градусной дуги
real ymin = 0;                       
real ymax_scaled = y_start_raw - y_end_raw; // Физическое падение 10-градусной дуги

// --- АВТОМАТИЧЕСКИЙ РАСЧЕТ СЕТКИ ДЛЯ ИДЕАЛЬНОГО ПОПАДАНИЯ В УЗЕЛ ---
int total_cells_y = 13; 

real cell_size = ymax_scaled / total_cells_y; 
int total_cells_x = round(xmax / cell_size);

// Гарантируем строгую изотропность (шаги осей равны -> ячейки квадратные)
real step_x = xmax / total_cells_x;
real step_y = ymax_scaled / total_cells_y;

int num_points = 4000; 

// Путь для обрезки (выделяет ровно одну первую ячейку из общей сетки)
path single_cell_clip = (xmin, ymin)--(xmin + step_x, ymin)--(xmin + step_x, ymin + step_y)--(xmin, ymin + step_y)--cycle;


// --- MULTI-CELL GRID BUILDER FUNCTION ---
void draw_base_grid(picture pic) {
    for(int i = 0; i <= total_cells_x; ++i) {
        real x = xmin + i * step_x;
        draw(pic, (x, ymin)--(x, ymax_scaled), gray+0.2pt);
    }
    for(int j = 0; j <= total_cells_y; ++j) {
        real y = ymin + j * step_y;
        draw(pic, (xmin, y)--(xmin + total_cells_x * step_x, y), gray+0.2pt);
    }
    draw(pic, (xmin, ymin)--(xmin + total_cells_x * step_x, ymin), gray+0.5pt);
    draw(pic, (xmin, ymax_scaled)--(xmin + total_cells_x * step_x, ymax_scaled), gray+0.5pt);
}


// ==========================================
// --- BLOCK B: ARC VARIANT -----------------
// ==========================================
picture row_arc;

// --- ЛЕВАЯ ПАНЕЛЬ: ОРИГИНАЛЬНАЯ ДУГА ---
picture p_arc_orig;
draw_base_grid(p_arc_orig); // Сетка на заднем плане

guide g_arc_orig;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    real x_orig = (r * cos(current_angle * pi / 180)) - x_start_raw;
    real y_orig = ymax_scaled + ((r * sin(current_angle * pi / 180)) - y_start_raw); 
    g_arc_orig = g_arc_orig -- (x_orig, y_orig);
}
draw(p_arc_orig, g_arc_orig, blue + 0.8pt); // Дуга на переднем плане


// --- ПРАВАЯ ПАНЕЛЬ: СВЕРНУТАЯ ЯЧЕЙКА ---
// Используем промежуточный слой, чтобы загнать рамку под график после clip()
picture p_arc_fold_base;
draw_base_grid(p_arc_fold_base); 

guide g_arc_fold;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    real x_orig = (r * cos(current_angle * pi / 180)) - x_start_raw;
    real y_orig = ymax_scaled + ((r * sin(current_angle * pi / 180)) - y_start_raw);
    
    // --- 2D ACCORDION FOLDING LOGIC ---
    int cell_index_x = floor((x_orig - xmin) / step_x);
    if (cell_index_x >= total_cells_x) cell_index_x = total_cells_x - 1;
    if (cell_index_x < 0) cell_index_x = 0;
    
    real x_inside_cell = x_orig - (xmin + cell_index_x * step_x);
    real x_final = (cell_index_x % 2 == 0) ? (xmin + x_inside_cell) : (xmin + step_x - x_inside_cell);
    
    int cell_index_y = floor((y_orig - ymin) / step_y);
    if (cell_index_y >= total_cells_y) cell_index_y = total_cells_y - 1;
    if (cell_index_y < 0) cell_index_y = 0;
    
    real y_inside_cell = y_orig - (ymin + cell_index_y * step_y);
    real y_final = (cell_index_y % 2 == 0) ? (ymin + y_inside_cell) : (ymin + step_y - y_inside_cell);
    
    g_arc_fold = g_arc_fold -- (x_final, y_final);
}
draw(p_arc_fold_base, g_arc_fold, blue + 0.3pt); // Рисуем график поверх сетки
clip(p_arc_fold_base, single_cell_clip);         // Обрезаем всю картинку по границам ячейки

picture p_arc_fold;
draw(p_arc_fold, single_cell_clip, gray + 0.3pt); // Сначала серая рамка на чистый фон
add(p_arc_fold, p_arc_fold_base);                 // Сверху накладываем обрезанный график

add(row_arc, p_arc_orig);
add(row_arc, shift(xmax + step_x, 0) * p_arc_fold);


// ==========================================
// --- BLOCK C: HIGH-MAGNIFICATION ZOOM -----
// ==========================================
picture p_zoom_base;
draw_base_grid(p_zoom_base); 
draw(p_zoom_base, g_arc_fold, blue + 0.3pt); 
clip(p_zoom_base, single_cell_clip); 

picture p_zoom;
draw(p_zoom, single_cell_clip, gray + 0.3pt); // Серая рамка на задний фон для ZOOM
add(p_zoom, p_zoom_base); 

picture p_zoom_scaled;
real zoom_factor = 15;
add(p_zoom_scaled, scale(zoom_factor) * p_zoom);


// ==========================================
// --- FINAL COMPOSITION AND DIMENSION ------
// ==========================================
add(row_arc);

// Выравнивание нижнего окна строго по центру ряда
real grid_center_x = (xmin + total_cells_x * step_x) / 2;
real zoom_center_x = (step_x * zoom_factor) / 2;

real aligned_shift_x = grid_center_x - zoom_center_x;

// МАТЕМАТИЧЕСКИ ТОЧНЫЙ СДВИГ ВНИЗ НА 1/4 ВЫСОТЫ:
real aligned_shift_y = -(step_y * zoom_factor) - (ymax_scaled / 4); 

add(shift(aligned_shift_x, aligned_shift_y) * p_zoom_scaled);

// Подпись оси слева
label("${\gg}R,H$", (0, ymax_scaled / 2), W);

// Автоматический расчет границ видимости для точного отображения с зазором в 1/4
real total_visual_height = (step_y * zoom_factor) + (ymax_scaled * 1.25);
limits(min(currentpicture) - (step_x * 2.0, total_visual_height * 0.05), max(currentpicture) + (step_x * 2.0, 0));
