// 1. SCIENTIFIC COMPACT WRAPPER FOR PAPERS
size(14cm, 0); 
import graph;

// --- GEOMETRIC CONFIGURATION (TRUE ARC 0 TO 180 DEGREES) ---
real r = 10;
real angle_start = 0;
real angle_end = 180;

// Для дуги 0-180 градусов ширина (xmax) равна диаметру 2*r, а высота — радиусу r
real xmin = 0;
real xmax = 2 * r; 
real ymin = 0;
real ymax = r;

// Low-profile vertical compression factor
real stretch_y = 1; 
real ymax_scaled = ymax * stretch_y;

// --- HIGH AND NARROW CELL CONFIGURATION ---
int total_cells_x = 500; 
int total_cells_y = 10; 

real step_x = xmax / total_cells_x; 
real step_y = ymax_scaled / total_cells_y; 

int num_points = 4000; 


// --- MULTI-CELL GRID BUILDER FUNCTION ---
void draw_base_grid(picture pic, bool single_cell) {
    if (!single_cell) {
        // Left Panel: Big original matrix
        for(int i = 0; i <= total_cells_x; ++i) {
            real x = xmin + i * step_x;
            draw(pic, (x, ymin)--(x, ymax_scaled), gray+0.2pt);
        }
        for(int j = 0; j <= total_cells_y; ++j) {
            real y = ymin + j * step_y;
            draw(pic, (xmin, y)--(xmin + total_cells_x * step_x, y), gray+0.2pt);
        }
        draw(pic, (xmin, ymin)--(xmin + total_cells_x * step_x, ymin), gray+0.5pt);
        draw(pic, (xmin, ymax_scaled)--(xmin + total_cells_x * step_x, ymax_scaled), gray+0.5pt);
    } else {
        // Right Panel: STRICTLY ONE SINGLE MICRO CELL BOX (High & Narrow)
        draw(pic, (xmin, ymin)--(xmin, ymin + step_y), gray+0.3pt);
        draw(pic, (xmin + step_x, ymin)--(xmin + step_x, ymin + step_y), gray+0.3pt);
        draw(pic, (xmin, ymin)--(xmin + step_x, ymin), gray+0.3pt);
        draw(pic, (xmin, ymin + step_y)--(xmin + step_x, ymin + step_y), gray+0.3pt);
    }
}


// ==========================================
// --- BLOCK B: ARC VARIANT -----------------
// ==========================================
picture row_arc;

picture p_arc_orig;
draw_base_grid(p_arc_orig, false);

guide g_arc_orig;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    // Центрируем дугу по X (сдвиг на +r), чтобы она шла от 0 до 2r
    real x_orig = r + r * cos(current_angle * pi / 180); 
    real y_orig = (r * sin(current_angle * pi / 180)) * stretch_y;
    g_arc_orig = g_arc_orig -- (x_orig, y_orig);
}
draw(p_arc_orig, g_arc_orig, blue + 0.8pt);

picture p_arc_fold;
draw_base_grid(p_arc_fold, true);

guide g_arc_fold;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    // Центрируем исходную дугу по X
    real x_orig = r + r * cos(current_angle * pi / 180); 
    real y_orig = (r * sin(current_angle * pi / 180)) * stretch_y;
    
    // --- 2D ACCORDION FOLDING LOGIC ---
    int cell_index_x = floor((x_orig - xmin) / step_x);
    if (cell_index_x >= total_cells_x) cell_index_x = total_cells_x - 1;
    if (cell_index_x < 0) cell_index_x = 0;
    
    real x_inside_cell = x_orig - (xmin + cell_index_x * step_x);
    real x_final = (cell_index_x % 2 == 0) ? (xmin + x_inside_cell) : (xmin + step_x - x_inside_cell);
    
    int cell_index_y = floor((y_orig - ymin) / step_y);
    if (cell_index_y >= total_cells_y) cell_index_y = total_cells_y - 1;
    if (cell_index_y < 0) cell_index_y = 0;
    
    real y_inside_cell = y_orig - (ymin + cell_index_y * step_y);
    real y_final = (cell_index_y % 2 == 0) ? (ymin + y_inside_cell) : (ymin + step_y - y_inside_cell);
    
    g_arc_fold = g_arc_fold -- (x_final, y_final);
}
draw(p_arc_fold, g_arc_fold, blue + 0.3pt);

add(row_arc, p_arc_orig);
add(row_arc, shift(xmax + step_x * 2.0, 0) * p_arc_fold);


// ==========================================
// --- BLOCK C: HIGH-MAGNIFICATION ZOOM -----
// ==========================================
picture p_zoom;

draw(p_zoom, (xmin, ymin)--(xmin, ymin + step_y), gray+0.3pt);
draw(p_zoom, (xmin + step_x, ymin)--(xmin + step_x, ymin + step_y), gray+0.3pt);
draw(p_zoom, (xmin, ymin)--(xmin + step_x, ymin), gray+0.3pt);
draw(p_zoom, (xmin, ymin + step_y)--(xmin + step_x, ymin + step_y), gray+0.3pt);

draw(p_zoom, g_arc_fold, blue + 0.3pt);

picture p_zoom_scaled;
real zoom_factor = 8;
add(p_zoom_scaled, scale(zoom_factor) * p_zoom);


// ==========================================
// --- FINAL COMPOSITION AND DIMENSION ------
// ==========================================
add(row_arc);

// PRECISE HORIZONTAL MIDPOINT CENTERING ALIGNMENT:
real grid_center_x = (xmin + total_cells_x * step_x) / 2;
real zoom_center_x = (step_x * zoom_factor) / 2;

real aligned_shift_x = grid_center_x - zoom_center_x;

// МАТЕМАТИЧЕСКИЙ СДВИГ ВНИЗ: 
real aligned_shift_y = -(step_y * zoom_factor + ymax_scaled / 8); 

add(shift(aligned_shift_x, aligned_shift_y) * p_zoom_scaled);

// Height axis notation on the left edge
label("${\gg}H$", (0, ymax_scaled / 2), W);

// Adjusted padding boundaries relative to the new layout footprint
limits(min(currentpicture) - (step_x * 4.0, ymax_scaled * 0.1), max(currentpicture) + (step_x * 4.0, 0));
