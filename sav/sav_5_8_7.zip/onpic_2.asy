// 1. SCIENTIFIC COMPACT WRAPPER FOR PAPERS
size(14cm, 0); 
import graph;

// --- GEOMETRIC CONFIGURATION (TRUE ARC 87 TO 90 DEGREES) ---
real r = 10;
real angle_start = 80;
real angle_end = 90;

real x_start_raw = r * cos(angle_start * pi / 180); 
real x_end_raw = r * cos(angle_end * pi / 180); 
real y_start_raw = r * sin(angle_start * pi / 180); 
real y_end_raw = r * sin(angle_end * pi / 180);

real xmin = 0;
real xmax = x_start_raw - x_end_raw;
real ymin = 0;
real ymax = y_end_raw - y_start_raw;

// Low-profile vertical compression factor
real stretch_y = 1; 
real ymax_scaled = ymax * stretch_y;

// REDUCED CELL COUNT CONFIGURATION:
// Decreased from 60x60 to 15x15 columns and rows for a cleaner, less dense layout
int total_cells_x = 15;
int total_cells_y = 15;

real step_x = xmax / total_cells_x; 
real step_y = ymax_scaled / total_cells_y; 

int num_points = 4000; 


// --- MULTI-CELL GRID BUILDER FUNCTION ---
void draw_base_grid(picture pic, bool single_cell) {
    if (!single_cell) {
        // Left Panel: Big original matrix (15x15 cells)
        for(int i = 0; i <= total_cells_x; ++i) {
            real x = xmin + i * step_x;
            draw(pic, (x, ymin)--(x, ymax_scaled), gray+0.2pt);
        }
        for(int j = 0; j <= total_cells_y; ++j) {
            real y = ymin + j * step_y;
            draw(pic, (xmin, y)--(xmin + total_cells_x * step_x, y), gray+0.2pt);
        }
        draw(pic, (xmin, ymin)--(xmin + total_cells_x * step_x, ymin), gray+0.5pt);
        draw(pic, (xmin, ymax_scaled)--(xmin + total_cells_x * step_x, ymax_scaled), gray+0.5pt);
    } else {
        // Right Panel: STRICTLY ONE SINGLE MICRO CELL BOX (1x1 cell bounds)
        draw(pic, (xmin, ymin)--(xmin, ymin + step_y), gray+0.3pt);
        draw(pic, (xmin + step_x, ymin)--(xmin + step_x, ymin + step_y), gray+0.3pt);
        draw(pic, (xmin, ymin)--(xmin + step_x, ymin), gray+0.3pt);
        draw(pic, (xmin, ymin + step_y)--(xmin + step_x, ymin + step_y), gray+0.3pt);
    }
}


// ==========================================
// --- BLOCK B: ARC VARIANT -----------------
// ==========================================
picture row_arc;

picture p_arc_orig;
draw_base_grid(p_arc_orig, false);

guide g_arc_orig;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    real x_orig = (r * cos(current_angle * pi / 180)) - x_end_raw;
    real y_orig = ((r * sin(current_angle * pi / 180)) - y_start_raw) * stretch_y;
    g_arc_orig = g_arc_orig -- (x_orig, y_orig);
}
draw(p_arc_orig, g_arc_orig, blue + 0.8pt);

picture p_arc_fold;
draw_base_grid(p_arc_fold, true);

guide g_arc_fold;
for(int i = 0; i <= num_points; ++i) {
    real t = i / num_points;
    real current_angle = angle_start + t * (angle_end - angle_start);
    
    real x_orig = (r * cos(current_angle * pi / 180)) - x_end_raw;
    real y_orig = ((r * sin(current_angle * pi / 180)) - y_start_raw) * stretch_y;
    
    // --- 2D ACCORDION FOLDING LOGIC ---
    int cell_index_x = floor((x_orig - xmin) / step_x);
    if (cell_index_x >= total_cells_x) cell_index_x = total_cells_x - 1;
    if (cell_index_x < 0) cell_index_x = 0;
    
    real x_inside_cell = x_orig - (xmin + cell_index_x * step_x);
    real x_final = (cell_index_x % 2 == 0) ? (xmin + x_inside_cell) : (xmin + step_x - x_inside_cell);
    
    int cell_index_y = floor((y_orig - ymin) / step_y);
    if (cell_index_y >= total_cells_y) cell_index_y = total_cells_y - 1;
    if (cell_index_y < 0) cell_index_y = 0;
    
    real y_inside_cell = y_orig - (ymin + cell_index_y * step_y);
    real y_final = (cell_index_y % 2 == 0) ? (ymin + y_inside_cell) : (ymin + step_y - y_inside_cell);
    
    g_arc_fold = g_arc_fold -- (x_final, y_final);
}
draw(p_arc_fold, g_arc_fold, blue + 0.3pt);

add(row_arc, p_arc_orig);
add(row_arc, shift(xmax + step_x * .5, 0) * p_arc_fold);


// ==========================================
// --- BLOCK C: HIGH-MAGNIFICATION ZOOM -----
// ==========================================
picture p_zoom;

draw(p_zoom, (xmin, ymin)--(xmin, ymin + step_y), gray+0.3pt);
draw(p_zoom, (xmin + step_x, ymin)--(xmin + step_x, ymin + step_y), gray+0.3pt);
draw(p_zoom, (xmin, ymin)--(xmin + step_x, ymin), gray+0.3pt);
draw(p_zoom, (xmin, ymin + step_y)--(xmin + step_x, ymin + step_y), gray+0.3pt);

draw(p_zoom, g_arc_fold, blue + 0.3pt);

picture p_zoom_scaled;
// Optimized zoom scale factor since the baseline cell step size is now 4 times larger
real zoom_factor = 4;
add(p_zoom_scaled, scale(zoom_factor) * p_zoom);


// ==========================================
// --- FINAL COMPOSITION AND DIMENSION ------
// ==========================================
add(row_arc);

// PRECISE HORIZONTAL MIDPOINT CENTERING ALIGNMENT:
real grid_center_x = (xmin + total_cells_x * step_x) / 2;
real zoom_center_x = (step_x * zoom_factor) / 2;

real aligned_shift_x = grid_center_x - zoom_center_x;

// МАТЕМАТИЧЕСКИЙ СДВИГ ВНИЗ ДЛЯ СЕТКИ 15х15:
// Опускаем блок ровно на собственную высоту (`step_y * zoom_factor`) + четверть высоты сети (`ymax_scaled / 4`)
real aligned_shift_y = -(step_y * zoom_factor + ymax_scaled / 4); 

add(shift(aligned_shift_x, aligned_shift_y) * p_zoom_scaled);

// Height axis notation on the left edge
label("\({\sim}R\)", (0, ymax_scaled / 2), W);

// Adjusted padding boundaries relative to the new layout footprint
// Нижнее поле расширено динамически, чтобы график не обрезался при компиляции
limits(min(currentpicture) - (step_x * 2.0, ymax_scaled * 0.1), max(currentpicture) + (step_x * 2.0, 0));
